--Add Playermodel
player_manager.AddValidModel( "arksoldier", "models/guy/arksoldier.mdl" )
player_manager.AddValidHands( "arksoldier", "models/hands/hands.mdl", 0, "00000000" )

local Category = "Arksoldier"

local NPC =
{
	Name = "Reunion_Soldier(Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/arksoldierNPC.mdl",
	Weapons = {  "weapon_shotgun" },
	Category = Category
}

list.Set( "NPC", "reunion_soldier_friendly", NPC )

local NPC =
{
	Name = "Reunion_Soldier (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/arksoldierNPCENEMY.mdl",
	Weapons = {  "weapon_ar2" },
	Category = Category        
}

list.Set( "NPC", "reunion_soldier_enemy", NPC )